export default {
  mainColor: '#3292E0',
};
