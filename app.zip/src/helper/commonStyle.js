export default {
  regular: 'Montserrat-Regular',
  Italic: 'Montserrat-Italic',
  Bold: 'Montserrat-Bold',
  Black: 'Montserrat-Black',
};
