Logo = require('../Images/LOGO_GS.png');

export default {Logo};
