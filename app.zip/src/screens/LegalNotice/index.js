//import liraries
import React, {Component} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import styles from './styles';

// create a component
const LegalNotice = () => {
  return (
    <View style={styles.container}>
      <ScrollView scrollEnable={true}>
        <Text style={styles.AllTextContainer}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec
          faucibus odio vel metus vehicula condimentum. Proin urna ante, dapibus
          nec tellus vel, gravida aliquam dui. Proin at lorem id augue dapibus
          auctor. Nulla facilisi. Praesent hendrerit neque ligula, eget placerat
          purus ullamcorper in. Fusce accumsan magna eu tellus molestie rhoncus.
          Donec sed accumsan lorem, et fringilla libero. Donec sit amet nisi in
          nisl venenatis ultrices. {'\n'}
          {'\n'}Donec quis nunc eu neque convallis consectetur vel at leo.
          Aenean lacinia lorem dui. Nulla tempor risus urna, id semper nisi
          suscipit sed. Integer cursus lobortis ligula. Curabitur ac nunc
          consequat mauris scelerisque luctus. In dui orci, mollis a interdum
          eget, ultricies sit amet nulla. Vivamus tortor orci, pretium id nibh
          sed, pellentesque tincidunt nisi. Suspendisse leo tortor, sagittis sed
          enim a, condimentum fermentum sem. Donec laoreet at elit ac congue.
          Etiam hendrerit pharetra elit vel cursus. Duis viverra sapien sem, eu
          luctus mauris iaculis a.
          {'\n'}
          {'\n'}Vestibulum faucibus aliquam posuere. Donec et nulla velit. Nulla
          venenatis vehicula justo, eget fermentum nibh lobortis eu. Quisque non
          mauris nulla. Ut eget rutrum ex. Nulla vehicula massa quis molestie
          dapibus. Nullam ut consectetur odio. Proin a sodales mauris. Ut
          hendrerit risus at sollicitudin suscipit. Quisque iaculis purus vel
          semper euismod. Nullam euismod varius turpis mattis consectetur. Sed
          commodo turpis sed volutpat sagittis. Curabitur mollis rhoncus dui, ac
          facilisis magna fringilla quis. Nunc id justo eu lectus congue
          imperdiet sed eu lectus. Vestibulum ante ipsum primis in faucibus orci
          luctus et ultrices posuere cubilia curae;{'\n'}
          {'\n'}
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec
          faucibus odio vel metus vehicula condimentum. Proin urna ante, dapibus
          nec tellus vel, gravida aliquam dui. Proin at lorem id augue dapibus
          auctor. Nulla facilisi. Praesent hendrerit neque ligula, eget placerat
          purus ullamcorper in. Fusce accumsan magna eu tellus molestie rhoncus.
          Donec sed accumsan lorem, et fringilla libero. Donec sit amet nisi in
          nisl venenatis ultrices. {'\n'}
          {'\n'}
          {'\n'}Donec quis nunc eu neque convallis consectetur vel at leo.
          Aenean lacinia lorem dui. Nulla tempor risus urna, id semper nisi
          suscipit sed. Integer cursus lobortis ligula. Curabitur ac nunc
          consequat mauris scelerisque luctus. In dui orci, mollis a interdum
          eget, ultricies sit amet nulla. Vivamus tortor orci, pretium id nibh
          sed, pellentesque tincidunt nisi. Suspendisse leo tortor, sagittis sed
          enim a, condimentum fermentum sem. Donec laoreet at elit ac congue.
          Etiam hendrerit pharetra elit vel cursus. Duis viverra sapien sem, eu
          luctus mauris iaculis a.
          {'\n'}Vestibulum faucibus aliquam posuere. Donec et nulla velit. Nulla
          venenatis vehicula justo, eget fermentum nibh lobortis eu. Quisque non
          mauris nulla. Ut eget rutrum ex. Nulla vehicula massa quis molestie
          dapibus. Nullam ut consectetur odio. Proin a sodales mauris. Ut
          hendrerit risus at sollicitudin suscipit. Quisque iaculis purus vel
          semper euismod. Nullam euismod varius turpis mattis consectetur. Sed
          commodo turpis sed volutpat sagittis. Curabitur mollis rhoncus dui, ac
          facilisis magna fringilla quis. Nunc id justo eu lectus congue
          imperdiet sed eu lectus. Vestibulum ante ipsum primis in faucibus orci
          luctus et ultrices posuere cubilia curae;{'\n'}
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec
          faucibus odio vel metus vehicula condimentum. Proin urna ante, dapibus
          nec tellus vel, gravida aliquam dui. Proin at lorem id augue dapibus
          auctor. Nulla facilisi. Praesent hendrerit neque ligula, eget placerat
          purus ullamcorper in. Fusce accumsan magna eu tellus molestie rhoncus.
          Donec sed accumsan lorem, et fringilla libero. Donec sit amet nisi in
          nisl venenatis ultrices. {'\n'}
          {'\n'}Donec quis nunc eu neque convallis consectetur vel at leo.
          Aenean lacinia lorem dui. Nulla tempor risus urna, id semper nisi
          suscipit sed. Integer cursus lobortis ligula. Curabitur ac nunc
          consequat mauris scelerisque luctus. In dui orci, mollis a interdum
          eget, ultricies sit amet nulla. Vivamus tortor orci, pretium id nibh
          sed, pellentesque tincidunt nisi. Suspendisse leo tortor, sagittis sed
          enim a, condimentum fermentum sem. Donec laoreet at elit ac congue.
          Etiam hendrerit pharetra elit vel cursus. Duis viverra sapien sem, eu
          luctus mauris iaculis a.
          {'\n'}
          {'\n'}Vestibulum faucibus aliquam posuere. Donec et nulla velit. Nulla
          venenatis vehicula justo, eget fermentum nibh lobortis eu. Quisque non
          mauris nulla. Ut eget rutrum ex. Nulla vehicula massa quis molestie
          dapibus. Nullam ut consectetur odio. Proin a sodales mauris. Ut
          hendrerit risus at sollicitudin suscipit. Quisque iaculis purus vel
          semper euismod. Nullam euismod varius turpis mattis consectetur. Sed
          commodo turpis sed volutpat sagittis. Curabitur mollis rhoncus dui, ac
          facilisis magna fringilla quis. Nunc id justo eu lectus congue
          imperdiet sed eu lectus. Vestibulum ante ipsum primis in faucibus orci
          luctus et ultrices posuere cubilia curae;
        </Text>
      </ScrollView>
    </View>
  );
};

//make this component available to the app
export default LegalNotice;
